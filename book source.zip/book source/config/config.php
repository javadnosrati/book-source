<?php

define('APP_CONFIG', [
    'DB' => [
        'hostname' => 'localhost',
        'username' => 'root',
        'password' => '',
        'database' => 'book_source'
    ]
]);
